import cowsay

cowsay.tux('This docker works!')
